/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Model.DataBase;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author ashifshakib
 */
public class DAO 
{
    private Connection connection;

    public DAO()
    {
        connection = DataBase.getConnection();
    }
   public List<User> getAllUsers()
    {
        List<User> users = new ArrayList<User>();
        try{
            PreparedStatement ps = connection.prepareStatement("SELECT * FROM users");
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()){
                String firstname= rs.getString("firstname");
                String lastname= rs.getString("lastname");
                String Email = rs.getString("Email");
                String password = rs.getString("password");
                String role=rs.getString("role");
                int number = rs.getInt("number");
                User myUser = new User(firstname,lastname,Email,password,role,number);
                users.add(myUser);
            }
      }catch (Exception e)
      {
          e.printStackTrace();
      }
      return users;
    }
       
    public void addUsers(User user)
    {
        try
        {
            PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO users(firstname,lastname,Email,password,role,number) VALUES(?,?,?,?,?,?)");
            
            preparedStatement.setString(1, user.getFirstname());
            preparedStatement.setString(2, user.getLastname());
            preparedStatement.setString(3, user.getEmail());
            preparedStatement.setString(4, user.getPassword());
            preparedStatement.setString(5, user.getRole());
            preparedStatement.setInt(6, user.getNumber());
            preparedStatement.executeUpdate();
        } catch(SQLException ex)
        {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE,null,ex);
        }
    }
    
    public void deleteUser(String Email)
    {
        try
        {
            PreparedStatement preparedStatement = connection.prepareStatement("DELETE FROM users WHERE Email=?");
            
            preparedStatement.setString(1,Email);
            preparedStatement.executeUpdate();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    public String authenticUser(User user) throws SQLException
    {
        String Email=user.getEmail();
        String password=user.getPassword();
        
        try
        {
            PreparedStatement ps=connection.prepareStatement("select Email,password,role from users ");
            ResultSet rs=ps.executeQuery();
            while(rs.next())
            {
                String email=rs.getString("Email");
                String Password=rs.getString("password");
                String role=rs.getString("role");
                
                if(Email.equals(email)&& password.equals(Password)&& role.equals("admin"))
                    return "admin";
                else if(Email.equals(email)&& password.equals(Password)&& role.equals("complaintHandler"))
                    return "complaintHandler";
                else if(Email.equals(email)&& password.equals(Password)&& role.equals("complainer"))
                    return "complainer";
                
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        
        }
        return "invalid";           
    }
    public boolean chechkUsers(String Email)
    {
        boolean st=false;
        try
        {
            PreparedStatement ps=connection.prepareStatement("SELECT Email FROM users WHERE Email=?  ");
            ps.setString(1, Email);
            ResultSet rs=ps.executeQuery();
            st=rs.next();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return st;
    }
    public void addComplain(Complaint complaint)
     {
          try
          {
            PreparedStatement preparedStatement= connection.prepareStatement("INSERT INTO complaint(Email,schoolname,city,district,type,description,status,comid)"
                    +" values(?,?,?,?,?,?,?,?)");
            
//   
           preparedStatement.setString(1, complaint.getEmail());
           preparedStatement.setString(2, complaint.getSchoolname());
           preparedStatement.setString(3, complaint.getCity());
           preparedStatement.setString(4, complaint.getDistrict());
           preparedStatement.setString(5, complaint.getType());
           preparedStatement.setString(6, complaint.getDescription()); 
           preparedStatement.setString(7, complaint.getStatus());
           preparedStatement.setInt(8, complaint.getComid());
           preparedStatement.executeUpdate();
           
        } 
          catch (SQLException ex)
          {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE,null,ex);
        }
     }
    public List<Complaint> getAllComplains()
    {
        List<Complaint> complains = new ArrayList<Complaint>();
        try{
            PreparedStatement ps = connection.prepareStatement("SELECT * FROM complaint WHERE status='PENDING'");
            ResultSet rs = ps.executeQuery();
            
            while(rs.next())
            {
                int comid=rs.getInt("comid");
                String Email = rs.getString("Email");
                String Schoolname=rs.getString("schoolname");
                String city=rs.getString("city");
                String district=rs.getString("district");
                String type=rs.getString("type");
                String description=rs.getString("description");
                String status=rs.getString("status");
                Complaint allcomplains = new Complaint(comid,Email,Schoolname,city,district,type,description,status);
                complains.add(allcomplains);
            }
      }
        catch (Exception e)
        {
          e.printStackTrace();
      }
      return complains;
    }
    public void Contact(Contact contact)
    {
        PreparedStatement ps;
        try
        {
            ps=connection.prepareStatement("INSERT INTO Contact(fullname,Email,subject,message) VALUES(?,?,?,?)");
            ps.setString(1,contact.getFullname());
            ps.setString(2,contact.getEmail());
            ps.setString(3,contact.getSubject());
            ps.setString(4,contact.getMessage());
            ps.executeUpdate();
        }
        catch(SQLException ex)
        {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE,null,ex);
        }
               
    }
    public List<Contact> getAllMessages()
    {
        List<Contact> contact = new ArrayList<Contact>();
        try{
            PreparedStatement ps = connection.prepareStatement("SELECT * FROM Contact");
            ResultSet rs = ps.executeQuery();
            
            while(rs.next())
            {
                String fullname = rs.getString("fullname");
                String Email=rs.getString("Email");
                String subject=rs.getString("subject");
                String message=rs.getString("message");
               
                Contact allmessages = new Contact(fullname,Email,subject,message);
                contact.add(allmessages);
            }
      }
        catch (Exception e)
        {
          e.printStackTrace();
      }
      return contact;
    }
    
    public List<Complaint> getComplaintDescriptionforcomplainer(String email)
    {
        List<Complaint> getdescription = new ArrayList<Complaint>();
        try
        {
            PreparedStatement ps = connection.prepareStatement("SELECT comid,description,status FROM complaint WHERE Email=?");
           ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            
            while(rs.next()) 
            {
                int comid=rs.getInt("comid");
                String description = rs.getString("description");
                String status=rs.getString("status");
                
               
                Complaint allDescription = new Complaint(description,status,comid);
                getdescription.add(allDescription);
            }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
        
        return getdescription;
    }
    
    public void RejectComplaint(String comid)
    {
        try
        {
            PreparedStatement ps = connection.prepareStatement("DELETE FROM complaint WHERE comid=?");
            ps.setString(1, comid);
            ps.executeUpdate();
        }
        catch(SQLException ex)
        {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE,null,ex);
        }
    }
    public void AcceptComplaint(String comid)
    {
        try
        {
            PreparedStatement ps=connection.prepareStatement("UPDATE complaint SET status=? WHERE comid=?");
            ps.setString(1, "");
            ps.setString(2, comid);
            ps.executeUpdate();
        }
        catch(SQLException ex)
        {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE,null,ex);   
        }
    }
    public void ChangeStatus(String comid,String status)
    {
        try
        {
            PreparedStatement ps=connection.prepareStatement("UPDATE complaint SET status=? WHERE comid=?");
            ps.setString(1, status);
            ps.setString(2, comid);
            ps.executeUpdate();
        }
        catch(SQLException ex)
        {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE,null,ex);   
        }
        
    }
    public List<Complaint> getAllcompletedcomplaints()
    {
        List<Complaint> complains = new ArrayList<Complaint>();
        try{
            PreparedStatement ps = connection.prepareStatement("SELECT * FROM complaint WHERE status='COMPLETED'");
            ResultSet rs = ps.executeQuery();
            
            while(rs.next())
            {
                int comid=rs.getInt("comid");
                String Email = rs.getString("Email");
                String Schoolname=rs.getString("schoolname");
                String city=rs.getString("city");
                String district=rs.getString("district");
                String type=rs.getString("type");
                String description=rs.getString("description");
                String status=rs.getString("status");
                Complaint allcomplains = new Complaint(comid,Email,Schoolname,city,district,type,description,status);
                complains.add(allcomplains);
            }
      }
        catch (Exception e)
        {
          e.printStackTrace();
      }
      return complains;
    }
    
    public List<Complaint> getNotPendingComplaints()
    {
        List<Complaint>complaints=new ArrayList<Complaint>();
    
    try
    {
        PreparedStatement ps=connection.prepareStatement("SELECT * FROM complaint WHERE status!='PENDING'");
        ResultSet rs=ps.executeQuery();
        while(rs.next())
        {
            int comid=rs.getInt("comid");
            String Email=rs.getString("Email");
            String Schoolname=rs.getString("schoolname");
            String city=rs.getString("city");
            String district=rs.getString("district");
            String type=rs.getString("type");
            String description=rs.getString("description");
            String status=rs.getString("status");
            Complaint notpending=new Complaint(comid,Email,Schoolname,city,district,type,description,status);
            complaints.add(notpending);
            
        }
        
    }
    catch(Exception e)
    {
        e.printStackTrace();
    }
    return complaints;
    }
     public List<Complaint> getAllcompletedcomplaintsforadmin()
    {
        List<Complaint> complains = new ArrayList<Complaint>();
        try{
            PreparedStatement ps = connection.prepareStatement("SELECT * FROM complaint");
            ResultSet rs = ps.executeQuery();
            
            while(rs.next())
            {
                int comid=rs.getInt("comid");
                String Email = rs.getString("Email");
                String Schoolname=rs.getString("schoolname");
                String city=rs.getString("city");
                String district=rs.getString("district");
                String type=rs.getString("type");
                String description=rs.getString("description");
                String status=rs.getString("status");
                Complaint allcomplains = new Complaint(comid,Email,Schoolname,city,district,type,description,status);
                complains.add(allcomplains);
            }
      }
        catch (Exception e)
        {
          e.printStackTrace();
      }
      return complains;
    }
     public List<Complaint> getAllcompletedcomplaintsVisitor()
     {
          List<Complaint> complains = new ArrayList<Complaint>();
        try{
            PreparedStatement ps = connection.prepareStatement("SELECT * FROM complaint WHERE status='COMPLETED'");
            ResultSet rs = ps.executeQuery();
            
            while(rs.next())
            {
                int comid=rs.getInt("comid");
                String Email = rs.getString("Email");
                String Schoolname=rs.getString("schoolname");
                String city=rs.getString("city");
                String district=rs.getString("district");
                String type=rs.getString("type");
                String description=rs.getString("description");
                String status=rs.getString("status");
                Complaint allcomplains = new Complaint(comid,Email,Schoolname,city,district,type,description,status);
                complains.add(allcomplains);
            }
      }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return complains;
     }
    public List<Complaint> SearchComplaintsComplaintHandler(String Comid) throws SQLException 
    {
         List<Complaint> complains = new ArrayList<Complaint>();
        try
        {
        PreparedStatement ps = connection.prepareStatement("SELECT * FROM complaint WHERE comid=?");
        ps.setString(1, Comid);
        ResultSet rs=ps.executeQuery();
            
        while(rs.next())
        {
            int comid=rs.getInt("comid");
            String Email = rs.getString("Email");
            String Schoolname=rs.getString("schoolname");
            String city=rs.getString("city");
            String district=rs.getString("district");
            String type=rs.getString("type");
            String description=rs.getString("description");
            String status=rs.getString("status");
            Complaint allcomplains = new Complaint(comid,Email,Schoolname,city,district,type,description,status);
            complains.add(allcomplains);            
        }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        return complains;
    }
    

    

}
        
        
        
    
            
    

