/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author ashifshakib
 */
public class Complaint
{
    private String Email,Schoolname,city,district,type,description,status;
    private int comid;

    public Complaint(int comid, String Email, String Schoolname, String city, String district, String type, String description, String status) {
        this.comid = comid;
        this.Email = Email;
        this.Schoolname = Schoolname;
        this.city = city;
        this.district = district;
        this.type = type;
        this.description = description;
        this.status = status;
    }

    public Complaint(String description, String status, int comid) {
        this.description = description;
        this.status = status;
        this.comid = comid;
    }
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) 
    {
        this.status = status;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getSchoolname() {
        return Schoolname;
    }

    public void setSchoolname(String Schoolname) {
        this.Schoolname = Schoolname;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getDistrict() {
        return district;
    }

    public void setDistrict(String district) {
        this.district = district;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getComid() {
        return comid;
    }

    public void setComid(int comid) {
        this.comid = comid;
    }
    

   
    
}
    
            
    

   