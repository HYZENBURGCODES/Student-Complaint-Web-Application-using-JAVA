/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Complaint;
import Model.Contact;
import Model.DAO;
import Model.User;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ashifshakib
 */
public class userControl extends HttpServlet  
{
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
             
        try {
            String command = request.getParameter("command");
            if(command == null)
            {
                command="VIEWCOMPLAINT";
            }
            
            switch(command)
            {
                case "ADD" :AddUsers(request, response);
                case "ADDCOMPLAINT":AddComplaint(request,response);
                default:
            }
        } catch (Exception ex) {
            Logger.getLogger(userControl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

       
    @Override
    public String getServletInfo() 
    {
        return "Short description";
    }      
    private void AddUsers(HttpServletRequest request, HttpServletResponse response)
            throws Exception{
        DAO dao = new DAO();
        
        String firstname = request.getParameter("firstname");
        String lastname=request.getParameter("lastname");
        String Email = request.getParameter("Email");
        String password= request.getParameter("password");
        String role = "complainer";
        int number= Integer.parseInt(request.getParameter("Number"));
        
        User newusers = new User (firstname,lastname,Email,password,role,number);
        dao.addUsers(newusers);
        
        RequestDispatcher dispatcher=request.getRequestDispatcher("index.html");
        dispatcher.forward(request, response);
    }
    private void AddComplaint(HttpServletRequest request, HttpServletResponse response)
    throws Exception
    {
        DAO dao= new DAO();
        int comid=0;
        String Email=request.getParameter("Email");
        String schoolname=request.getParameter("Schoolname");
        String city=request.getParameter("city");
        String district=request.getParameter("district");
        String type=request.getParameter("Complaint Reguarding?");
        String description=request.getParameter("description");
        String status="PENDING";
        
        Complaint complaint= new Complaint(comid,Email,schoolname,city,district,type,description,status);
        dao.addComplain(complaint);
        
        response.sendRedirect("ComplainersHomePage.jsp");
    }

}
