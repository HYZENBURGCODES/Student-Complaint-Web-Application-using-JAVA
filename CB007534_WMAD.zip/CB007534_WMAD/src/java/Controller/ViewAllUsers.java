/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.DAO;
import Model.User;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ashifshakib
 */
public class ViewAllUsers extends HttpServlet 
{
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        try {
            String command = request.getParameter("command");
            if(command == null)
            {
                command="LIST";
            }
            
            switch(command)
            {
                case "LIST":ListUsers(request, response);
                case "DELETE":DeleteUser(request,response);
                
            }
        } catch (Exception ex) {
            Logger.getLogger(userControl.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
       
    }
    @Override
    public String getServletInfo() 
    {
        return "Short description";
    }
     private void ListUsers(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {

        DAO dao = new DAO();

       List<User> users = dao.getAllUsers();
       request.setAttribute("USER_LIST", users);

        RequestDispatcher dispatcher = request.getRequestDispatcher("Listuser.jsp");
        dispatcher.forward(request, response);
        
        response.sendRedirect("AdminHomePage.jsp");

    }
     private void DeleteUser(HttpServletRequest request, HttpServletResponse response)
            throws Exception
    {
        DAO dao = new DAO();
        
        String Email = request.getParameter("Email");
        
        dao.deleteUser(Email);
        ListUsers(request,response);
    }

}
