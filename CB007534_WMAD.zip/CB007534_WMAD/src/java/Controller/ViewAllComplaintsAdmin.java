/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Complaint;
import Model.DAO;
import Model.User;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ashifshakib
 */
public class ViewAllComplaintsAdmin extends HttpServlet 
{
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        try {
            String command = request.getParameter("command");
            if(command == null)
            {
                command="COM_LIST";
            }
            
            switch(command)
            {
                case "COM_LIST":getAllComplains(request, response);
                case "DELETE":ComplaintReject(request,response);
                case "ACCEPT":ComplaintAccept(request,response);
                default:
                
            }
        } catch (Exception ex) {
            Logger.getLogger(userControl.class.getName()).log(Level.SEVERE, null, ex);
        }
       
        
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
       
    }
    @Override
    public String getServletInfo() 
    {
        return "Short description";
    }
      
    private void getAllComplains(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        DAO dao= new DAO();
        List<Complaint>  complains=dao.getAllComplains();
        request.setAttribute("COM_LIST",complains);
        
        RequestDispatcher dispatcher=request.getRequestDispatcher("AdminHomePage.jsp");
        dispatcher.forward(request, response);
        
        

    }
     public void ComplaintReject(HttpServletRequest request, HttpServletResponse response) throws Exception 
     {
        DAO dao = new DAO();
        
        String comid = request.getParameter("comid");
        
        dao.RejectComplaint(comid);
        
//        RequestDispatcher dispatcher = request.getRequestDispatcher("AdminHomePage.jsp");
//        dispatcher.forward(request, response);
        getAllComplains(request,response);
     }
     public void ComplaintAccept(HttpServletRequest request, HttpServletResponse response) throws Exception 
     {
        DAO dao = new DAO();
        
        String comid = request.getParameter("comID");
        
        dao.AcceptComplaint(comid);
        
//        RequestDispatcher dispatcher = request.getRequestDispatcher("AdminHomePage.jsp");
//        dispatcher.forward(request, response);
        getAllComplains(request,response);
     }
     
    
         

}
