/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Contact;
import Model.DAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ashifshakib
 */
public class ShowMessage extends HttpServlet 
{
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
               
        try {
            String command = request.getParameter("command");
            if(command == null)
            {
                command="VIEWM";
            }
            
            switch(command)
            {
                case "CONTACT" :ContactMessage(request,response);
                case "VIEWM" :ListMessages(request,response);
               
            }
        } catch (Exception ex) {
            Logger.getLogger(userControl.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        
    }
    @Override
    public String getServletInfo() 
    {
        return "Short description";
    }

    private void ContactMessage(HttpServletRequest request, HttpServletResponse response)
    throws Exception
    {
        DAO dao= new DAO();
        
        String fullname=request.getParameter("fullname");
        String Email=request.getParameter("Email");
        String subject=request.getParameter("subject");
        String message=request.getParameter("message");
        
        Model.Contact contact=new Model.Contact(fullname,Email,subject,message);
        dao.Contact(contact);
        
      response.sendRedirect("Contact.jsp");
        
    }
    private void ListMessages(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
        DAO dao= new DAO();
        List<Contact> contact=dao.getAllMessages();
        request.setAttribute("M_LIST",contact);
        
        RequestDispatcher dispatcher=request.getRequestDispatcher("GetMessage.jsp");
        dispatcher.forward(request, response);
        
    }

}

