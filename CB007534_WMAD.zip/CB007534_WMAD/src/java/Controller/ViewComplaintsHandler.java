/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Complaint;
import Model.DAO;
import java.util.logging.Logger;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


/**
 *
 * @author ashifshakib
 */
public class ViewComplaintsHandler extends HttpServlet
{
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        try
        {
            String command=request.getParameter("command");
            if(command==null)
            {
                command="COMH_LIST";
            }
            switch(command)
            {
                case "COMH_LIST": ViewNotPendingComplaints(request,response);
                case "CH_STATUS": setStatus(request,response);
            }
        }
        catch(Exception ex)
        {
            Logger.getLogger(ViewComplaintsHandler.class.getName()).log(Level.SEVERE,null,ex);
        }
        
       
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
       
    }
    @Override
    public String getServletInfo() 
    {
        return "Short description";
    }// </editor-fold>
    
     private void ViewNotPendingComplaints (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
     {
         DAO dao= new DAO();
         
         List<Complaint>complaints=dao.getNotPendingComplaints();
         
         request.setAttribute("COMH_LIST", complaints);
         RequestDispatcher dispatcher=request.getRequestDispatcher("ComplaintHandlersHomePage.jsp");
         dispatcher.forward(request, response);
         
         
     }
     public void setStatus (HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
     {
         DAO dao= new DAO();
         
         String comid=request.getParameter("comid");
         String status=request.getParameter("status");
         
         switch(status)
         {
             case"1":
             {
                 status="COMPLETED";
                 dao.ChangeStatus(comid, status);
                 break;
             }
             case"2":
             {
                 status="IN-PROGRESS";
                 dao.ChangeStatus(comid, status);
                 break;
             }
             case"3":
             {
                 status="OUT OF SCOPE";
                 dao.ChangeStatus(comid, status);
                 break;
             }
             default:
                 break;
                 
                 
         }
         ViewNotPendingComplaints(request,response);
         
     }
}
