/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Complaint;
import Model.DAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author ashifshakib
 */
public class ViewComplaintsVisitor extends HttpServlet 
{
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
         try {
            String command = request.getParameter("command");
            if(command == null)
            {
                command="DONE_COM";
            }
            
            switch(command)
            {
                
                case "DONE_COM":viewcompletedcomplaintsvisitor(request,response);
                default:
                
            }
        } catch (Exception ex) {
            Logger.getLogger(userControl.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {
        
    }
    @Override
    public String getServletInfo()
    {
        return "Short description";
    }
    private void viewcompletedcomplaintsvisitor(HttpServletRequest request, HttpServletResponse response)
    throws Exception
    {
        DAO dao= new DAO();
        
        List<Complaint>  complains=dao.getAllcompletedcomplaintsVisitor();
        request.setAttribute("DONE_COM",complains);
        
        RequestDispatcher dispatcher=request.getRequestDispatcher("viewcomplains.jsp");
        dispatcher.forward(request, response);
        
        
    }

}
