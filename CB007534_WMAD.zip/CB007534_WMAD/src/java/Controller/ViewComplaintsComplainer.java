/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.Complaint;
import Model.DAO;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author ashifshakib
 */
public class ViewComplaintsComplainer extends HttpServlet 
{
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException 
    {   
        DAO dao= new DAO();
        String email=request.getParameter("Email");
       
        List<Complaint>  getdescription=dao.getComplaintDescriptionforcomplainer(email);
        request.setAttribute("GET_DES",getdescription);       
        RequestDispatcher dispatcher=request.getRequestDispatcher("ViewComplaintsComplainer.jsp");
        dispatcher.forward(request, response);
    }
    
    @Override
    public String getServletInfo() 
    {
        return "Short description";
    }

}
